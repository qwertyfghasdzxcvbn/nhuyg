# Backend Web Apps

## Install Dependencies
### `npm install --prefix`

## Running Apps
### `npm run start-apps`
