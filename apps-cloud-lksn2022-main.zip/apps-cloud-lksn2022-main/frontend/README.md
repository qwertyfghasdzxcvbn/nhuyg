# Getting Started Web Apps LKSN Cloud Computing 2022

## Install Dependencies
### `npm install`

## Available Scripts

Before running apps, you must install library serve, because serve not include from dependencies
### `npm install serve`

In the project directory, you can run:

### `npm run start`

## Run Web Apps
open browser and access your ip + port, ex : localhost:3000

