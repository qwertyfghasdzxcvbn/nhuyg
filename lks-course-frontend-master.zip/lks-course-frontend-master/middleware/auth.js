export default async function ({ $auth, store, route, redirect }) {
   // console.log(store.state);
   // console.log(test);
   // const user = await $auth.loggedIn;
   // console.log(user);
   // if (user) {
   //    console.log($route.name);
   // } else {
   //    // redirect to homepage
   //    redirect("/login");
   // }
}
