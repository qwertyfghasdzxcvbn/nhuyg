export default function ({ $auth }) {
   // if ($auth.loggedIn) {
   //    const a = $auth.user;
   //    console.log(a);
   // }
   // $auth.onRedirect((to, from) => {
   //    console.log(to);
   //    // you can optionally change `to` by returning a new value
   // });
   // $auth.onError((error, name, endpoint) => {
   //    console.log(error);
   // });
}
