import Vue from "vue";
import { Icon } from "@iconify/vue2";

// Vue.use(Icon);
Vue.component("iconify", Icon);
